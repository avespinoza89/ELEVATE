import { withPluginApi } from "discourse/lib/plugin-api";

const DEEPL_FREE_API = "https://api-free.deepl.com/v2";
const DEEPL_PRO_API = "https://api.deepl.com/v2";

const LANGUAGE_NAMES = {
  'ar': 'Arabic', 'bg': 'Bulgarian', 'cs': 'Czech', 'da': 'Danish',
  'de': 'German', 'el': 'Greek', 'en': 'English', 'es': 'Spanish',
  'et': 'Estonian', 'fi': 'Finnish', 'fr': 'French', 'hu': 'Hungarian',
  'id': 'Indonesian', 'it': 'Italian', 'ja': 'Japanese', 'ko': 'Korean',
  'lt': 'Lithuanian', 'lv': 'Latvian', 'nb': 'Norwegian', 'nl': 'Dutch',
  'pl': 'Polish', 'pt': 'Portuguese', 'ro': 'Romanian', 'ru': 'Russian',
  'sk': 'Slovak', 'sl': 'Slovenian', 'sv': 'Swedish', 'tr': 'Turkish',
  'uk': 'Ukrainian', 'zh': 'Chinese'
};

function initializeDeeplTranslation(api) {
  const siteSettings = api.container.lookup("service:site-settings");

  // Translation service
  const DeepLTranslator = {

    getApiUrl() {
      return settings.deepl_use_free_api ? DEEPL_FREE_API : DEEPL_PRO_API;
    },

    async translate(text, targetLang, sourceLang = null) {
      const apiKey = settings.deepl_api_key;

      if (!apiKey || apiKey.trim() === '') {
        console.error('[DeepL] API key not configured');
        return null;
      }

      // Check cache first
      if (settings.cache_translations) {
        const cached = this.getCached(text, targetLang);
        if (cached) return cached;
      }

      const url = `${this.getApiUrl()}/translate`;
      const params = new URLSearchParams({
        'text': text,
        'target_lang': this.normalizeLanguageCode(targetLang),
        'auth_key': apiKey
      });

      if (sourceLang) {
        params.append('source_lang', this.normalizeLanguageCode(sourceLang));
      }

      try {
        const response = await fetch(url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: params.toString()
        });

        if (!response.ok) {
          console.error('[DeepL] API error:', response.status, await response.text());
          return null;
        }

        const data = await response.json();

        if (data.translations && data.translations[0]) {
          const translation = {
            text: data.translations[0].text,
            detectedSourceLang: data.translations[0].detected_source_language?.toLowerCase() || sourceLang
          };

          // Cache the translation
          if (settings.cache_translations) {
            this.setCached(text, targetLang, translation);
          }

          return translation;
        }

        return null;
      } catch (error) {
        console.error('[DeepL] Translation error:', error);
        return null;
      }
    },

    normalizeLanguageCode(code) {
      const normalized = code.toLowerCase();
      if (normalized === 'en') return 'EN';
      if (normalized === 'pt') return 'PT-BR';
      if (normalized === 'zh') return 'ZH';
      return code.toUpperCase();
    },

    getCacheKey(text, targetLang) {
      return `deepl_cache_${btoa(text).substring(0, 50)}_${targetLang}`;
    },

    getCached(text, targetLang) {
      try {
        const cached = localStorage.getItem(this.getCacheKey(text, targetLang));
        if (cached) {
          const data = JSON.parse(cached);
          // Cache valid for 24 hours
          if (Date.now() - data.timestamp < 24 * 60 * 60 * 1000) {
            return data.translation;
          }
        }
      } catch (e) {
        console.warn('[DeepL] Cache read error:', e);
      }
      return null;
    },

    setCached(text, targetLang, translation) {
      try {
        localStorage.setItem(this.getCacheKey(text, targetLang), JSON.stringify({
          translation,
          timestamp: Date.now()
        }));
      } catch (e) {
        console.warn('[DeepL] Cache write error:', e);
      }
    },

    getUserLanguage() {
      return localStorage.getItem('deepl_user_language') || settings.default_language || 'en';
    },

    setUserLanguage(lang) {
      localStorage.setItem('deepl_user_language', lang);
    }
  };

  // Initialize the plugin
  api.onPageChange(() => {

    // Add language selector to user menu
    if (api.getCurrentUser()) {
      const addLanguageSelector = () => {
        const existingSelector = document.getElementById('deepl-language-selector');
        if (existingSelector) return;

        const chatContainer = document.querySelector('.chat-drawer');
        if (!chatContainer) return;

        const selectorHtml = `
          <div id="deepl-language-selector" class="deepl-language-selector">
            <label for="deepl-lang-select">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
              </svg>
              Your Language:
            </label>
            <select id="deepl-lang-select" class="deepl-lang-select">
              ${Object.entries(LANGUAGE_NAMES).map(([code, name]) =>
                `<option value="${code}" ${DeepLTranslator.getUserLanguage() === code ? 'selected' : ''}>${name}</option>`
              ).join('')}
            </select>
          </div>
        `;

        const header = chatContainer.querySelector('.chat-drawer-header');
        if (header && !document.getElementById('deepl-language-selector')) {
          header.insertAdjacentHTML('beforeend', selectorHtml);

          const select = document.getElementById('deepl-lang-select');
          if (select) {
            select.addEventListener('change', (e) => {
              DeepLTranslator.setUserLanguage(e.target.value);
              console.log('[DeepL] Language changed to:', e.target.value);
              // Refresh chat to show translations
              location.reload();
            });
          }
        }
      };

      // Try to add selector when chat opens
      setTimeout(addLanguageSelector, 1000);

      // Also watch for chat drawer opening
      const observer = new MutationObserver(() => {
        addLanguageSelector();
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true
      });
    }
  });

  // Intercept and translate chat messages
  api.modifyClass("component:chat-message", {
    pluginId: "deepl-chat-translation",

    didInsertElement() {
      this._super(...arguments);

      if (!settings.auto_translate_enabled) return;
      if (!settings.deepl_api_key) return;

      const messageText = this.message?.message;
      if (!messageText) return;

      const userLang = DeepLTranslator.getUserLanguage();
      const messageElement = this.element;

      // Translate the message
      this.translateMessage(messageText, userLang, messageElement);
    },

    async translateMessage(text, targetLang, element) {
      try {
        const translation = await DeepLTranslator.translate(text, targetLang);

        if (!translation) return;

        const sourceLang = translation.detectedSourceLang;

        // Don't translate if same language
        if (sourceLang === targetLang) return;

        const translatedText = translation.text;
        const messageContentElement = element.querySelector('.chat-message-text');

        if (!messageContentElement) return;

        // Store original text
        if (!messageContentElement.dataset.originalText) {
          messageContentElement.dataset.originalText = text;
          messageContentElement.dataset.translatedText = translatedText;
          messageContentElement.dataset.sourceLang = sourceLang;
        }

        // Replace with translated text
        messageContentElement.innerHTML = translatedText;

        // Add translation badge
        if (settings.show_translation_badge) {
          this.addTranslationBadge(element, sourceLang, text, translatedText);
        }

      } catch (error) {
        console.error('[DeepL] Translation failed:', error);
      }
    },

    addTranslationBadge(element, sourceLang, originalText, translatedText) {
      const existingBadge = element.querySelector('.deepl-translation-badge');
      if (existingBadge) return;

      const languageName = LANGUAGE_NAMES[sourceLang] || sourceLang.toUpperCase();

      const badgeHtml = `
        <div class="deepl-translation-badge">
          <span class="translation-indicator">
            <svg class="translation-icon" width="14" height="14" viewBox="0 0 24 24">
              <path fill="currentColor" d="M12.87 15.07l-2.54-2.51.03-.03c1.74-1.94 2.98-4.17 3.71-6.53H17V4h-7V2H8v2H1v1.99h11.17C11.5 7.92 10.44 9.75 9 11.35 8.07 10.32 7.3 9.19 6.69 8h-2c.73 1.63 1.73 3.17 2.98 4.56l-5.09 5.02L4 19l5-5 3.11 3.11.76-2.04zM18.5 10h-2L12 22h2l1.12-3h4.75L21 22h2l-4.5-12zm-2.62 7l1.62-4.33L19.12 17h-3.24z"/>
            </svg>
            Translated from ${languageName}
          </span>
          ${settings.show_original_toggle ? `
            <button class="btn-flat btn-small deepl-toggle-btn">Show Original</button>
          ` : ''}
        </div>
      `;

      const messageContainer = element.querySelector('.chat-message-container');
      if (messageContainer) {
        messageContainer.insertAdjacentHTML('beforeend', badgeHtml);

        // Add toggle functionality
        const toggleBtn = messageContainer.querySelector('.deepl-toggle-btn');
        if (toggleBtn) {
          toggleBtn.addEventListener('click', () => {
            const messageContentElement = element.querySelector('.chat-message-text');
            const isShowingOriginal = toggleBtn.dataset.showing === 'original';

            if (isShowingOriginal) {
              messageContentElement.innerHTML = messageContentElement.dataset.translatedText;
              toggleBtn.textContent = 'Show Original';
              toggleBtn.dataset.showing = 'translated';
            } else {
              messageContentElement.innerHTML = messageContentElement.dataset.originalText;
              toggleBtn.textContent = 'Show Translation';
              toggleBtn.dataset.showing = 'original';
            }
          });
        }
      }
    }
  });
}

export default {
  name: "deepl-chat-translation",
  initialize() {
    withPluginApi("0.11.0", initializeDeeplTranslation);
  }
};
